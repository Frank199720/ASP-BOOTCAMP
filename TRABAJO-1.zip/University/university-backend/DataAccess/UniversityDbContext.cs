﻿using Microsoft.EntityFrameworkCore;
using university_backend.Models.DataModels;

namespace university_backend.DataAccess
{
    public class UniversityDbContext : DbContext
    {
        public UniversityDbContext( DbContextOptions<UniversityDbContext> options ) : base( options )
        {

        }

        //Add DbSets (Database's Tables)
        public DbSet<User>? Users { get; set; }
        public DbSet<Grade>? Grades { get; set; }

    }
}
